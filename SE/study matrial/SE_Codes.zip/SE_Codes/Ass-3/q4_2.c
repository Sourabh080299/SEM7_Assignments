#include <stdio.h>

int x, y;
int f(void) /*@globals x;@*/
{
    return y;
}