#include <stdio.h>

extern void setx(int *x, int *y) /*@modifies *y@*/;
void setx(int *x, int *y) /*@modifies *x@*/
{
    // do stuff
}