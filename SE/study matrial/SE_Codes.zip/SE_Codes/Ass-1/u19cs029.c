#include<stdio.h>
//#include<conio.h>
int sum(int a, int b)
{
    return c = a+b;
}
int *sumans(int a, int b)
{
    int *ptr;
    ptr = a+b;
}
int main()
{
    printf("%d",a);
    int a = 10, c;
    int *pi;
    pi = NULL;
    c = *pi;
    //return 0;
}