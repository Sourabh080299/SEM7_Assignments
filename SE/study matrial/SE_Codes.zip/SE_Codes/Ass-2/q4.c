#include<stdio.h>
struct s
{
    int a;
    int b;
    float c;
}s1={.b=2,.c=3.0};

int main()
{
    return 0;
}
