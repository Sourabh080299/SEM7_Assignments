#include<stdio.h>
int a;
int main()
{
    int c, d;
    c=a;
    d=5;
    printf("c + d = %d", c+d);
    //fun();
    return 0;
}
