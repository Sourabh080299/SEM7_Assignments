#include<stdio.h>
int a;
int fun()
{
    return a;
}
int main()
{
    printf("-> %d",fun());
    return 0;
}
