#include<stdio.h>
int a=5, b;
int main()
{
    int c, d;
    c=2;
    d=5;
    printf("c + d = %d", c+d);
    return 0;
}
